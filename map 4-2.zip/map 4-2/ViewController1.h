//
//  ViewController1.h
//  map
//
//  Created by appzoc on 28/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController1 : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *nm;
@property (strong, nonatomic) IBOutlet UITextField *ag;
@property (strong, nonatomic) IBOutlet UITextField *plc;
@property (strong, nonatomic) IBOutlet UIButton *btn;
@property (strong, nonatomic) IBOutlet UITextField *search;
@property (strong, nonatomic) IBOutlet UIButton *srchbtn;
@property (strong, nonatomic) IBOutlet UIButton *sortbtn;
@property (strong, nonatomic) IBOutlet UIButton *updatebtn;
@property (strong, nonatomic) IBOutlet UIButton *deletebtn;

- (IBAction)save:(id)sender;

- (IBAction)srchbtnn:(id)sender;
- (IBAction)srtbtttn:(id)sender;
- (IBAction)updatebtnact:(id)sender;
- (IBAction)deletebtnact:(id)sender;

@end
