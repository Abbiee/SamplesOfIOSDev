//
//  map.m
//  map
//
//  Created by appzoc on 28/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import "map.h"
#import <MapKit/MapKit.h>
#import "ViewController1.h"
@interface map ()
{
    MKMapView *ma;
}
@end

@implementation map

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    ma=[[MKMapView alloc]initWithFrame:CGRectMake(10, 10, 310, 400)];
    MKCoordinateRegion r;
    MKCoordinateSpan s;
    CLLocationCoordinate2D c;
    c.latitude=9.9940;
    c.longitude=76.2920;
    s.latitudeDelta=.04;
    s.longitudeDelta=.04;
    r.center=c;
    r.span=s;
    [ma setRegion:r];
    [self.view addSubview:ma];
    MKPointAnnotation *p=[[MKPointAnnotation alloc]init];
    [p setCoordinate:c];
    [p setTitle:@"erm"];
    [p setSubtitle:@"kaloor"];
    [ma addAnnotation:p];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)data:(id)sender {
    ViewController1 *vc1=[[ViewController1 alloc]init];
    [self.navigationController pushViewController:vc1 animated:YES];
}
@end
