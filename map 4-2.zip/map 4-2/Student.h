//
//  Student.h
//  map
//
//  Created by appzoc on 28/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Student : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSNumber * age;
@property (nonatomic, retain) NSString * place;

@end
