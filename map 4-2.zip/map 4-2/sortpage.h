//
//  sortpage.h
//  map
//
//  Created by appzoc on 31/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sortpage : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *srt;
@property (strong,nonatomic)NSArray *array;

@end
