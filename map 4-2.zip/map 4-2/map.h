//
//  map.h
//  map
//
//  Created by appzoc on 28/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface map : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *btn;
- (IBAction)data:(id)sender;

@end
