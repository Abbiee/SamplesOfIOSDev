//
//  ViewController1.m
//  map
//
//  Created by appzoc on 28/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import "ViewController1.h"
#import "Student.h"
#import "AppDelegate.h"
#import "tableViewController.h"
#import "sortpage.h"
@interface ViewController1 ()
{
    AppDelegate *app;
    NSArray *fetchedObjects2;
}

@end

@implementation ViewController1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    app=(AppDelegate *)[UIApplication sharedApplication].delegate;
    
    
    
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)srtbtn:(id)sender {
}

- (IBAction)save:(id)sender
{
    Student *sd=[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:app.managedObjectContext];
    
    sd.name=_nm.text;
    sd.age=[NSNumber numberWithInt:[_ag.text integerValue]];
    sd.place=_plc.text;
    
    [app saveContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:app.managedObjectContext];
[fetchRequest setEntity:entity];

NSError *error = nil;
NSArray *fetchedObjects1 = [app.managedObjectContext executeFetchRequest:fetchRequest error:&error];
if (fetchedObjects1 == nil) {
    
}

    
    if(fetchedObjects1.count!=0)
    {
        for (int i=0; i<fetchedObjects1.count; i++)
        {
            NSLog(@"%@",[[fetchedObjects1 objectAtIndex:i]valueForKey:@"name"]);
            NSLog(@"%@",[NSString stringWithFormat:@"%@",[[fetchedObjects1 objectAtIndex:i]valueForKey:@"age"]]);
            NSLog(@"%@",[[fetchedObjects1 objectAtIndex:i]valueForKey:@"place"]);
        }
    }
    
    
}



- (IBAction)srtbtttn:(id)sender {
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student"
inManagedObjectContext:app.managedObjectContext];
[fetchRequest setEntity:entity];

NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name"
ascending:YES];
NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
[fetchRequest setSortDescriptors:sortDescriptors];

NSError *error = nil;
NSArray * fetchedObjects = [app.managedObjectContext executeFetchRequest:fetchRequest error:&error];
if (fetchedObjects == nil) {
    // Handle the error
}

    sortpage *sort=[[sortpage alloc]init];
   sort.array=fetchedObjects;
    [self.navigationController pushViewController:sort animated:YES];
    

}

- (IBAction)updatebtnact:(id)sender
{
    for (NSManagedObject *obj in fetchedObjects2)
    {
        [obj setValue:_nm.text forKey:@"name"];
        [obj setValue:_plc.text forKey:@"place"];
        [obj setValue:[NSNumber numberWithInt:[_ag.text intValue]] forKey:@"age"];
        
        [app saveContext];

        
    }
    
}

- (IBAction)deletebtnact:(id)sender
{
for (NSManagedObject *obj in fetchedObjects2)

    [app.managedObjectContext deleteObject:obj];
    [app saveContext];
    
}

- (IBAction)srchbtnn:(id)sender
{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:app.managedObjectContext];
[fetchRequest setEntity:entity];

NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name like %@", self.search.text];
[fetchRequest setPredicate:predicate];

NSError *error = nil;
fetchedObjects2 = [app.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    
    tableViewController *tvc=[[tableViewController alloc]init];
    tvc.array=fetchedObjects2;
    [self.navigationController pushViewController:tvc animated:YES];
    
    
    
    
}
@end
