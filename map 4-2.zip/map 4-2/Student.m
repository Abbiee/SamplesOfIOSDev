//
//  Student.m
//  map
//
//  Created by appzoc on 28/07/15.
//  Copyright (c) 2015 Infinity. All rights reserved.
//

#import "Student.h"


@implementation Student

@dynamic name;
@dynamic age;
@dynamic place;

@end
